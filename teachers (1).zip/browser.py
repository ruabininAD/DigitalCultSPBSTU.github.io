from selenium import webdriver
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup, element

import re
import json
import time
import random
import typing as t

Chrome = webdriver.Chrome()
Host = "https://www.elibrary.ru"
StartPage = "https://www.elibrary.ru/author_items.asp"


class Public:
    """Public dataclass definition."""
    name: str = ""
    year: int = 0
    doi: str = ""
    url: str = ""
    authors: t.List[str] = []

    def dict(self) -> t.Dict:
        return {
            "name": self.name,
            "year": self.year,
            "doi": self.doi,
            "url": self.url,
            "authors": self.authors
        }


def fetch_public(index: element.Tag) -> Public:
    """Fetch all public info by given"""
    public = Public()

    def _find_link(soup: BeautifulSoup) -> str:
        if atag := soup.find_all('a', href=re.compile(r'^https://doi.org')):
            return atag[0].text
        return ''

    # Get basic info in index html element
    if name := index.find('a'):
        if isinstance(name, element.Tag):
            public.name = name.text
    if authors := index.find('font'):
        public.authors = authors.text.split(', ')
    if year := re.findall(r"\b\d{4}\b", index.text):
        public.year = int(year[0])

    # Find doi and public type info in detail page
    if isinstance(name, element.Tag):
        url = name.attrs.get('href')
        if url and url.startswith("/item.asp"):
            public.url = url
            Chrome.get(Host + url)
            if Chrome.title == "Тест Тьюринга":
                input("CAPTCHA waiting...")
            soup = BeautifulSoup(Chrome.page_source, "html.parser")
            public.doi = _find_link(soup)

    return public


def parse_tds(soup: BeautifulSoup) -> t.Iterable[element.Tag]:
    """Fetch searching page all info tds."""
    table = soup.find(id="restab")
    if not isinstance(table, element.Tag):
        return
    for row in table.find_all("tr", id=True):
        info = row.find("td", align="left", valign="top")
        if info:
            yield info


def has_next_page(soup: BeautifulSoup) -> bool:
    """Check whether this is the last page."""
    if soup.find("a", title="Следующая страница"):
        return True
    return False


def save(publics: t.List[Public], filename: str) -> None:
    """Save to file."""
    with open(filename, 'w') as handler:
        json.dump([
            public.dict() for public in publics
        ], handler, indent=4, ensure_ascii=False)


def start(userid: int, username: str, sleep: int = 1) -> ...:
    """Start crawler."""
    pagenum = 1
    indexes = []

    # Fetch all indexes
    print(f"Fetching indexes on searching page: {pagenum} ... ", end="")
    Chrome.get(f"{StartPage}?authorid={userid}")
    while True:
        soup = BeautifulSoup(Chrome.page_source, "html.parser")
        parsed_indexes = list(parse_tds(soup))
        indexes.extend(parsed_indexes)
        print(f"{len(parsed_indexes)} indexes")
        if not parsed_indexes:
            input("CAPTCHA waiting...")
            continue
        if not has_next_page(soup):
            break
        next_page = Chrome.find_element(
            By.CSS_SELECTOR, value="a[title='Следующая страница']")
        pagenum += 1
        print(f"Fetching indexes on searching page: {pagenum} ... ", end="")
        time.sleep(sleep + random.randint(0, sleep))
        next_page.click()

    # Get detailed info by indexes
    publics = []
    for index in indexes:
        public = fetch_public(index)
        if public.url.startswith("/item.asp"):
            publics.append(public)
            print(f"Fetched public info: {public.url}")
            save(publics, f"{username}.json")
        time.sleep(sleep + random.randint(0, sleep))


if __name__ == "__main__":
    start(int(input("Userid: ")), input("Username: "))
    Chrome.close()
